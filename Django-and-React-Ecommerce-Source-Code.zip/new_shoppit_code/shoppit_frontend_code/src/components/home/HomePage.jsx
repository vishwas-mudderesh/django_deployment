import Header from './Header'
import CardContainer from './CardContainer'

const HomePage = () => {

  

  return (
    <>
    <Header />
    <CardContainer />
    </>
  )
}

export default HomePage
