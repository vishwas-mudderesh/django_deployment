import styles from "./PaymentSection.module.css"
import { BsFillCreditCard2FrontFill } from "react-icons/bs";
import { FaCcPaypal } from "react-icons/fa"

const PaymentSection = () => {

  return (
    <div className="col-md-4">
    <div className={`card ${styles.card}`}>
      <div className="card-header" style={{ backgroundColor: '#6050DC', color:"white"}}>
        <h5>Payment Options</h5>
      </div>
      <div className="card-body">
        {/* PayPal Button */}
        <button className={`btn btn-primary w-100 mb-3 ${styles.paypalButton}`} id="paypal-button">
        <FaCcPaypal style={{fontSize:"30px"}} /> Pay with PayPal
        </button>

        {/* Flutterwave Button */}
        <button className={`btn btn-warning w-100 ${styles.flutterwaveButton}`} id="flutterwave-button">
        <BsFillCreditCard2FrontFill  style={{fontSize:"30px"}} /> Pay with Flutterwave
        </button>
      </div>
    </div>
  </div>
  )
}

export default PaymentSection
